// ==UserScript==
// @name         SNOW
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Kirim pesan WA
// @author       Topyk
// @match http://web.whatsapp.com/*
// @match https://web.whatsapp.com/*
// @require https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    console.log("aktif");
    setTimeout(function(){
        console.log("mau klik");
        try
        {
            document.getElementsByClassName('_4sWnG')[0].click();
            GM_xmlhttpRequest({
                method: "POST",
                url: "http://192.168.182.67/snow/waku/statusPesan/ok",
                headers: {"Content-Type": "application/x-www-form-urlencoded"},
                onload: function(respon){
                    console.log(respon);
                }
            });
        }
        catch(Exception)
        {
            console.log(Exception);
            GM_xmlhttpRequest({
                method: "POST",
                url: "http://192.168.182.67/snow/waku/statusPesan/error",
                headers: {"Content-Type": "application/x-www-form-urlencoded"},
                onload: function(respon){
                    console.log(respon);
                    window.close();
                }
            });
        }
        setTimeout(function(){
            window.close();
        },5000);
    },15000);
})();