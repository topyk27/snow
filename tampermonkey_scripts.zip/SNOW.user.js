// ==UserScript==
// @name         SNOW
// @namespace    https://github.com/topyk27/snow
// @updateURL    https://openuserjs.org/meta/topyk/SNOW.meta.js
// @downloadURL  https://openuserjs.org/src/scripts/topyk/SNOW.user.js
// @version      0.4
// @description  Kirim pesan WA
// @author       Topyk
// @match http://web.whatsapp.com/*
// @match https://web.whatsapp.com/*
// @require https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js
// @grant        GM_xmlhttpRequest
// @license MIT
// ==/UserScript==

(function () {
  console.log("gasken");
  setTimeout(function () {
    console.log("mau klik");
    try {
      document.getElementsByClassName('epia9gcq')[0].click();
      GM_xmlhttpRequest({
        method: "POST",
        url: "http://localhost/snow/waku/statusPesan/ok",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        onload: function (respon) {
          console.log(respon);
        }
      });
    }
    catch (Exception) {
      console.log(Exception);
      GM_xmlhttpRequest({
        method: "POST",
        url: "http://localhost/snow/waku/statusPesan/error",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        onload: function (respon) {
          console.log(respon);
          window.close();
        }
      });
    }
    setTimeout(function () {
      window.close();
    }, 5000);
  }, (Math.floor(Math.random() * (55 - 50) ) + 50)*1000);
})();
