// ==UserScript==
// @name         SNOW
// @namespace    https://gist.github.com/topyk27/59280364d57af9e6ea4b5f6dd68e0a43
// @updateURL    https://gist.github.com/topyk27/59280364d57af9e6ea4b5f6dd68e0a43/raw/snow.user.js
// @downloadURL  https://gist.github.com/topyk27/59280364d57af9e6ea4b5f6dd68e0a43/raw/snow.user.js
// @version      0.9
// @description  Kirim pesan WA
// @author       Topyk
// @match http://web.whatsapp.com/*
// @match https://web.whatsapp.com/*
// @require https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js
// @grant        GM_xmlhttpRequest
// @license MIT
// ==/UserScript==

(function () {
  console.log("gasken ayolah update");
  setTimeout(function () {
    console.log("mau klik");
    try {
      document.getElementsByClassName('epia9gcq')[0].click();
      GM_xmlhttpRequest({
        method: "POST",
        url: "http://localhost/snow/waku/statusPesan/ok",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        onload: function (respon) {
          console.log(respon);
        }
      });
    }
    catch (Exception) {
      console.log(Exception);
      GM_xmlhttpRequest({
        method: "POST",
        url: "http://localhost/snow/waku/statusPesan/error",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        onload: function (respon) {
          console.log(respon);
          window.close();
        }
      });
    }
    setTimeout(function () {
      window.close();
    }, 2000);
  }, (Math.floor(Math.random() * (45 - 35)) + 35) * 1000);
})();
